command = [0, "A3"]
coordinate = command[1]
print(coordinate[0])