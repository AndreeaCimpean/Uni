#include "service.h"
#include <stdlib.h>

Service* create_service(Repository* repository, OperationsStack* undoStack, OperationsStack* redoStack)
{
	Service* newService = (Service*)malloc(sizeof(Service));
	if (newService == NULL)
		return NULL;
	newService->repository = repository;
	newService->undoStack = undoStack;
	newService->redoStack = redoStack;
	return newService;
}

void destroy_service(Service* service)
{
	destroy_repository(service->repository);
	destroy_operations_stack(service->undoStack);
	destroy_operations_stack(service->redoStack);
	free(service);
}

Profile** get_all_profiles_service(Service* service)
{
	return get_all_profiles_repository(service->repository);
}

void get_profiles_filtered_by_psychological_profile_service(Profile** filteredList, int* lengthOfFilteredList, Service* service, char* psychologicalProfile)
{
	Profile** list_of_profiles = get_all_profiles_service(service);
	int number_of_profiles = get_number_of_profiles_service(service);
	for (int i = 0; i < number_of_profiles; ++i)
	{
		Profile* current_profile = list_of_profiles[i];
		if (strcmp(get_pshycological_profile(current_profile), psychologicalProfile) == 0)
		{
			filteredList[*lengthOfFilteredList] = current_profile;
			(*lengthOfFilteredList)++;
		}
	}
}

int add_profile_service(Service* service, int profileId, char* placeOfBirth, char* psychologicalProfile, int yearsOfRecordedService)
{
	Profile* newProfile = create_profile(profileId, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
	int result_of_adding_profile = add_profile_repository(service->repository, newProfile);
	if (result_of_adding_profile == 1)
	{
		Operation* newOperationUndo = create_operation(newProfile, "add");
		push_to_operations_stack(service->undoStack, newOperationUndo);
		destroy_operation(newOperationUndo);
	}
	else
	{
		destroy_profile(newProfile);
	}
	return result_of_adding_profile;
}

int update_profile_service(Service* service, int profileId, char* newPlaceOfBirth, char* newPsychologicalProfile, int newYearsOfRecordedService)
{
	Profile* profile_before_update = copy_profile(get_profile_from_profiles_service(service, profileId));
	if (update_profile_repository(service->repository, profileId, newPlaceOfBirth, newPsychologicalProfile, newYearsOfRecordedService) == 0)
		return 0;
	else
	{
		Operation* newOperationUndo = create_operation(profile_before_update, "update");
		push_to_operations_stack(service->undoStack, newOperationUndo);
		destroy_operation(newOperationUndo);
		destroy_profile(profile_before_update);
		return 1;
	}
}

int delete_profile_service(Service* service, int profileId)
{
	Profile* profile_before_delete = copy_profile(get_profile_from_profiles_service(service, profileId));
	if (delete_profile_repository(service->repository, profileId) == 0)
		return 0;
	else
	{
		Operation* newOperationUndo = create_operation(profile_before_delete, "delete");
		push_to_operations_stack(service->undoStack, newOperationUndo);
		destroy_operation(newOperationUndo);
		destroy_profile(profile_before_delete);
		return 1;
	}
}

int get_number_of_profiles_service(Service* service)
{
	return get_number_of_profiles_repository(service->repository);
}

void get_newbies(Profile** filteredList, int* lengthOfFilteredList, Service* service, int maximumYearsOfService)
{
	Profile** list_of_profiles = get_all_profiles_service(service);
	int number_of_profiles = get_number_of_profiles_service(service);
	for (int i = 0; i < number_of_profiles; ++i)
	{
		Profile* current_profile = list_of_profiles[i];
		if (current_profile->yearsOfRecordedService<maximumYearsOfService)
		{
			filteredList[*lengthOfFilteredList] = current_profile;
			(*lengthOfFilteredList)++;
		}
	}
	for (int i = 0; i < *lengthOfFilteredList - 1; ++i)
	{
		for (int j = 0; j < *lengthOfFilteredList; ++j)
		{
			if (strcmp(filteredList[i]->placeOfBirth, filteredList[j]->placeOfBirth) > 0)
			{
				Profile* auxiliary_profile = filteredList[i];
				filteredList[i] = filteredList[j];
				filteredList[j] = auxiliary_profile;
			}
		}
	}
}

Profile* get_profile_from_profiles_service(Service* service, int profileId)
{
	return get_profile_from_lsit_of_profiles(service->repository, profileId);
}

int undo(Service* service)
{
	if (operations_stack_is_empty(service->undoStack))
		return 0;
	Operation* operation = pop_from_operations_stack(service->undoStack);
	Profile* profile = get_profile_from_operation(operation);
	if (strcmp(operation->operationType, "add") == 0)
	{
		Operation* newOperationRedo = create_operation(profile, "add");
		push_to_operations_stack(service->redoStack, newOperationRedo);
		destroy_operation(newOperationRedo);

		int profileId = get_profile_id_number(profile);
		delete_profile_repository(service->repository, profileId);
	}
	else if (strcmp(operation->operationType, "update") == 0)
	{
		Profile* current_profile = get_profile_from_profiles_service(service, profile->profileIdNumber);
		Operation* newOperationRedo = create_operation(current_profile, "update");
		push_to_operations_stack(service->redoStack, newOperationRedo);
		destroy_operation(newOperationRedo);

		int profileId = get_profile_id_number(profile);
		int yearsOfRecordedService = get_years_of_recorded_service(profile);
		char placeOfBirth[50], psychologicalProfile[50];
		strcpy(placeOfBirth, get_place_of_birth(profile));
		strcpy(psychologicalProfile, get_pshycological_profile(profile));
		update_profile_repository(service->repository, profileId, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
	}
	else
	{
		Operation* newOperationRedo = create_operation(profile, "delete");
		push_to_operations_stack(service->redoStack, newOperationRedo);
		destroy_operation(newOperationRedo);

		int profileId = get_profile_id_number(profile);
		int yearsOfRecordedService = get_years_of_recorded_service(profile);
		char placeOfBirth[50], psychologicalProfile[50];
		strcpy(placeOfBirth, get_place_of_birth(profile));
		strcpy(psychologicalProfile, get_pshycological_profile(profile));
		Profile* newProfile = create_profile(profileId, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
		add_profile_repository(service->repository, newProfile);
	}
	destroy_operation(operation);
	return 1;
}

int redo(Service* service)
{
	if (operations_stack_is_empty(service->redoStack))
		return 0;
	Operation* operation = pop_from_operations_stack(service->redoStack);
	Profile* profile = get_profile_from_operation(operation);
	if (strcmp(operation->operationType, "add") == 0)
	{
		Operation* newOperationUndo = create_operation(profile, "add");
		push_to_operations_stack(service->undoStack, newOperationUndo);
		destroy_operation(newOperationUndo);

		int profileId = get_profile_id_number(profile);
		int yearsOfRecordedService = get_years_of_recorded_service(profile);
		char placeOfBirth[50], psychologicalProfile[50];
		strcpy(placeOfBirth, get_place_of_birth(profile));
		strcpy(psychologicalProfile, get_pshycological_profile(profile));
		Profile* newProfile = create_profile(profileId, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
		add_profile_repository(service->repository, newProfile);
	}
	else if (strcmp(operation->operationType, "update") == 0)
	{
		Profile* profile_before_update = get_profile_from_profiles_service(service, profile->profileIdNumber);
		Operation* newOperationUndo = create_operation(profile_before_update, "update");
		push_to_operations_stack(service->undoStack, newOperationUndo);
		destroy_operation(newOperationUndo);

		int profileId = get_profile_id_number(profile);
		int yearsOfRecordedService = get_years_of_recorded_service(profile);
		char placeOfBirth[50], psychologicalProfile[50];
		strcpy(placeOfBirth, get_place_of_birth(profile));
		strcpy(psychologicalProfile, get_pshycological_profile(profile));
		update_profile_repository(service->repository, profileId, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
	}
	else
	{
		Operation* newOperationUndo = create_operation(profile, "delete");
		push_to_operations_stack(service->undoStack, newOperationUndo);
		destroy_operation(newOperationUndo);

		int profileId = get_profile_id_number(profile);
		delete_profile_repository(service->repository, profileId);
	}
	destroy_operation(operation);
	return 1;
}
