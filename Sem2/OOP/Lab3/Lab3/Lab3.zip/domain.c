#include "domain.h"
#include <string.h>
#include <stdlib.h>

Profile* create_profile(int profileIdNumber, char* placeOfBirth, char* psychologicalProfile, int yearsOfRecordedService)
{
	Profile* newProfile = (Profile*)malloc(sizeof(Profile));
	if (newProfile == NULL)
		return NULL;
	newProfile->profileIdNumber = profileIdNumber;
	newProfile->yearsOfRecordedService = yearsOfRecordedService;
	
	newProfile->placeOfBirth = (char*)malloc(sizeof(char) * (strlen(placeOfBirth) + 1));
	if (newProfile->placeOfBirth == NULL)
		return NULL;
	strcpy(newProfile->placeOfBirth, placeOfBirth);

	newProfile->psychologicalProfile = (char*)malloc(sizeof(char) * (strlen(psychologicalProfile) + 1));
	if (newProfile->psychologicalProfile == NULL)
		return NULL;
	strcpy(newProfile->psychologicalProfile, psychologicalProfile);

	return newProfile;
}

Profile* copy_profile(Profile* profile)
{
	if (profile == NULL)
		return NULL;
	Profile* copyProfile = create_profile(get_profile_id_number(profile), get_place_of_birth(profile), get_pshycological_profile(profile), get_years_of_recorded_service(profile));
	return copyProfile;
}

void destroy_profile(Profile* profile)
{
	if (profile == NULL)
		return;
	free(profile->placeOfBirth);
	free(profile->psychologicalProfile);
	free(profile);
}


int get_profile_id_number(Profile* profile)
{
	return profile->profileIdNumber;
}

int get_years_of_recorded_service(Profile* profile)
{
	return profile->yearsOfRecordedService;
}

char* get_place_of_birth(Profile* profile)
{
	return profile->placeOfBirth;
}

char* get_pshycological_profile(Profile* profile)
{
	return profile->psychologicalProfile;
}
