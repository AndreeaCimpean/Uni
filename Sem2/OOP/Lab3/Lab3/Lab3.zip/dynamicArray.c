#include "dynamicArray.h"
#include <stdlib.h>

DynamicArray* create_dynamic_array(int capacity)
{
	DynamicArray* newDynamicArray = (DynamicArray*)malloc(sizeof(DynamicArray));
	if (newDynamicArray == NULL)
		return NULL;
	newDynamicArray->capacity = capacity;
	newDynamicArray->length = 0;
	newDynamicArray->elements = (Element*)malloc(capacity * sizeof(Element));
	if (newDynamicArray->elements == NULL)
		return NULL;
	return newDynamicArray;
}

void destroy_dynamic_array(DynamicArray* dynamicArray)
{
	if (dynamicArray == NULL)
		return;
	for (int i = 0; i < dynamicArray->length; ++i)
		destroy_profile(dynamicArray->elements[i]);
	free(dynamicArray->elements);
	free(dynamicArray);
}

int resize_dynamic_array(DynamicArray* dynamicArray)
{
	if (dynamicArray == NULL)
		return -1;
	dynamicArray->capacity *= 2;
	Element* resized_list_of_elements = (Element*)realloc(dynamicArray->elements, dynamicArray->capacity * sizeof(Element));
	if (resized_list_of_elements == NULL)
		return -1;
	dynamicArray->elements = resized_list_of_elements;
	return 0;
}

void add_element_dynamic_array(DynamicArray* dynamicArray, Element element)
{
	if (dynamicArray == NULL)
		return;
	if (dynamicArray->elements == NULL)
		return;
	if (dynamicArray->length == dynamicArray->capacity)
		resize_dynamic_array(dynamicArray);
	dynamicArray->elements[dynamicArray->length++] = element;
}

void delete_element_from_dynamic_array(DynamicArray* dynamicArray, int position)
{
	if (dynamicArray == NULL || dynamicArray->elements == NULL)
		return;
	Element element = get_element_from_dynamic_array(dynamicArray, position);
	destroy_profile(element);
	for (int i = position; i < dynamicArray->length - 1; ++i)
		dynamicArray->elements[i] = dynamicArray->elements[i + 1];
	dynamicArray->length--;
}

int get_length_dynamic_array(DynamicArray* dynamicArray)
{
	if (dynamicArray == NULL)
		return -1;
	return dynamicArray->length;
}

Element get_element_from_dynamic_array(DynamicArray* dynamicArray, int position)
{
	if (dynamicArray == NULL)
		return NULL;
	if (position < 0 || position >= dynamicArray->length)
		return NULL;
	return dynamicArray->elements[position];
}
