#include "repository.h"
#include <string.h>
#include <stdlib.h>

Repository* create_repository()
{
	Repository* newRepository = (Repository*)malloc(sizeof(Repository));
	if (newRepository == NULL)
		return NULL;
	newRepository->profiles = create_dynamic_array(INITIAL_CAPACITY);
	return newRepository;
}

void destroy_repository(Repository* repository)
{
	if (repository == NULL)
		return;
	destroy_dynamic_array(repository->profiles);
	free(repository);
}


int find_profile_index_by_profile_id(Repository* repository, int profileId)
{
	/*
	return:
		the position of a profile in the list of profiles
		-1 if profile not in list
	*/
	for (int i = 0; i < repository->profiles->length; ++i)
		if(get_profile_id_number(repository->profiles->elements[i]) == profileId)
			return i;
	return -1;
}

int add_profile_repository(Repository* repository, Profile* profile)
{
	if (find_profile_index_by_profile_id(repository, profile->profileIdNumber) != -1)
		return 0;
	add_element_dynamic_array(repository->profiles, profile);
	return 1;
}

Profile** get_all_profiles_repository(Repository* repository)
{
	return repository->profiles->elements;
}

int update_profile_repository(Repository* repository, int profileId, char* newPlaceOfBirth, char* newPsychologicalProfile, int newYearsOfRecordedService)
{
	/*
	If profile found update it and return 1, otherwise return 0 
	*/
	int found_profile = find_profile_index_by_profile_id(repository, profileId);
	if (found_profile == -1)
		return 0;
	repository->profiles->elements[found_profile]->yearsOfRecordedService = newYearsOfRecordedService;
	strcpy(repository->profiles->elements[found_profile]->placeOfBirth, newPlaceOfBirth);
	strcpy(repository->profiles->elements[found_profile]->psychologicalProfile, newPsychologicalProfile);
	return 1;
}

int delete_profile_repository(Repository* repository, int profileId)
{
	/*
	If profile found delete it and return 1, otherwise return 0
	*/
	int found_profile = find_profile_index_by_profile_id(repository, profileId);
	if (found_profile == -1)
		return 0;
	delete_element_from_dynamic_array(repository->profiles, found_profile);
	return 1;
}

int get_number_of_profiles_repository(Repository* repository)
{
	return repository->profiles->length;
}

Profile* get_profile_from_lsit_of_profiles(Repository* repository, int profileId)
{
	return repository->profiles->elements[find_profile_index_by_profile_id(repository, profileId)];
}
