#include "operationStack.h"
#include <string.h>
#include <stdlib.h>

Operation* create_operation(Profile* profile, char* operationType)
{
	Operation* newOperation = (Operation*)malloc(sizeof(Operation));
	if (newOperation == NULL)
		return NULL;
	newOperation->profile = copy_profile(profile);
	newOperation->operationType = (char*)malloc(sizeof(char) * (strlen(operationType) + 1));
	strcpy(newOperation->operationType, operationType);
	return newOperation;
}

void destroy_operation(Operation* operation)
{
	if (operation == NULL)
		return;
	destroy_profile(operation->profile);
	free(operation->operationType);
	free(operation);
}

char* get_operation_type(Operation* operation)
{
	return operation->operationType;
}

Profile* get_profile_from_operation(Operation* operation)
{
	return operation->profile;
}

Operation* copy_operation(Operation* operation)
{
	if (operation == NULL)
		return NULL;
	Operation* copy_operation = create_operation(get_profile_from_operation(operation), get_operation_type(operation));
	return copy_operation;
}

OperationsStack* create_operations_stack()
{
	OperationsStack* newOperationsStack = (OperationsStack*)malloc(sizeof(OperationsStack));
	if (newOperationsStack == NULL)
		return NULL;
	newOperationsStack->length = 0;
	return newOperationsStack;
}

void destroy_operations_stack(OperationsStack* operationsStack)
{
	for (int i = 0; i < operationsStack->length; ++i)
		destroy_operation(operationsStack->operations[i]);
	free(operationsStack);
}

void push_to_operations_stack(OperationsStack* operationsStack, Operation* operation)
{
	Operation* copyOperation = copy_operation(operation);
	operationsStack->operations[operationsStack->length] = copyOperation;
	operationsStack->length++;
}

Operation* pop_from_operations_stack(OperationsStack* operationsStack)
{
	operationsStack->length--;
	return operationsStack->operations[operationsStack->length];
}

int operations_stack_is_empty(OperationsStack* operationsStack)
{
	return (operationsStack->length == 0);
}
