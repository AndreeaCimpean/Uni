#pragma once
#include "RepositoryInterafce.h"
#include "Evidence.h"
#include "EvidenceValidator.h"

class Service
{
private:
	std::string physicalCopiesFile;
	EvidenceValidator& evidenceValidator;
	RepositoryInterface& repository;
	std::vector<Evidence> physicalCopies;
	void save_physical_copies_to_file() const;
	void save_physical_copies_to_html() const;
	void save_physical_copies_to_csv() const;
	void write_html_header() const;
	void write_html_body_begin() const;
	void write_html_body_end() const;
public:
	Service(EvidenceValidator& evidenceValidator, RepositoryInterface& repository) : evidenceValidator{ evidenceValidator }, repository{ repository } {};
	void add_evidence(const Evidence& evidence);
	void update_evidence(const Evidence& evidence);
	void delete_evidence(const std::string& id);
	std::vector<Evidence> get_evidences() const;
	int get_number_of_evidences() const;
	Evidence next_evidence();
	void save_physical_copy(const std::string& id);
	int find_evidence_index_in_physical_copies_by_id(const std::string& id) const;
	const std::vector<Evidence>& get_physical_copies() const;
	int get_number_of_physical_copies() const;
	void filter_evidences_by_measurement_and_quantity(std::vector<Evidence>& filtered_list, const std::string& measurement, const double quantity) const;
	void set_repository_file(const std::string& file);
	void set_physical_copies_file(const std::string& file);
};

