#include "Service.h"
#include "MyExceptions.h"
#include "TextFileRepository.h"
#include "MemoryRepository.h"
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

void Service::save_physical_copies_to_file() const
{
	if (this->physicalCopiesFile.find(".csv") != std::string::npos || this->physicalCopiesFile.find(".txt") != std::string::npos)
		this->save_physical_copies_to_csv();
	else
		this->save_physical_copies_to_html();
}

void Service::save_physical_copies_to_html() const
{
	this->write_html_header();
	this->write_html_body_begin();
	for (auto evidence : this->physicalCopies)
		evidence.to_html(this->physicalCopiesFile);
	this->write_html_body_end();
}

void Service::save_physical_copies_to_csv() const
{
	ofstream output_file(this->physicalCopiesFile);
	for (auto evidence : this->physicalCopies)
		output_file << evidence << endl;
	output_file.close();
}

void Service::write_html_header() const
{
	ofstream output(this->physicalCopiesFile);
	output << "<!DOCTYPE html>" << endl;
	output << "<html>" << endl;
	output << "<head>" << endl;
	output << "<title>Evidences Database</title>" << endl;
	output << "</head>" << endl;
	output.close();
}

void Service::write_html_body_begin() const
{
	ofstream output(this->physicalCopiesFile, ios::app);
	output << "<body>" << endl;
	output << "<table border=\"1\">" << endl;
	output << "</tr>" << endl;
	output << "<td>Evidence Id</td>" << endl;
	output << "<td>Measurement</td>" << endl;
	output << "<td>Image Clarity Level</td>" << endl;
	output << "<td>Quantity</td>" << endl;
	output << "<td>Photograph</td>" << endl;
	output << "</tr>" << endl;
	output.close();
}

void Service::write_html_body_end() const
{
	ofstream output(this->physicalCopiesFile, ios::app);
	output << "</table>" << endl;
	output << "</body>" << endl;
	output << "</html>" << endl;
	output.close();
}

void Service::add_evidence(const Evidence& evidence)
{
	this->evidenceValidator.validate(evidence);
	this->repository.add_evidence(evidence);
}

void Service::update_evidence(const Evidence& evidence)
{
	/*
	Update an evidence in the list of evidences and in the physical copies as well
	*/
	this->evidenceValidator.validate(evidence);
	this->repository.update_evidence(evidence.get_id(), evidence.get_measurement(), evidence.get_image_clarity_level(), evidence.get_quantity(), evidence.get_photograph());
	int evidence_index = this->find_evidence_index_in_physical_copies_by_id(evidence.get_id());
	if (evidence_index != -1)
	{
		this->physicalCopies[evidence_index] = evidence;
		this->save_physical_copies_to_file();
	}
}

void Service::delete_evidence(const std::string& id)
{
	/*
	Delete an evidence from the list of evidences and from the physical copies as well
	*/
	this->repository.delete_evidence(id);
	int evidence_index= this->find_evidence_index_in_physical_copies_by_id(id);
	if (evidence_index != -1)
	{
		this->physicalCopies.erase(this->physicalCopies.begin() + evidence_index);
		this->save_physical_copies_to_file();
	}
	
}

std::vector<Evidence> Service::get_evidences() const
{
	return this->repository.get_evidences();
}

int Service::get_number_of_evidences() const
{
	return this->repository.get_number_of_evidences();
}

Evidence Service::next_evidence()
{
	/*
	Return the next evidence to be displayed to the user
	*/
	return this->repository.next_evidence();
}

void Service::save_physical_copy(const std::string& id)
{
	/*
	Save a copy of an evidence in the list of physical copies
	parameter: id - the id of the evidence to be saved
	*/
	Evidence copy_evidence = this->repository.get_evidence_by_id(id);
	if (find_evidence_index_in_physical_copies_by_id(id) != -1)
		throw ServiceException("Evidence already saved!\n");
	this->physicalCopies.push_back(copy_evidence);
	if (this->physicalCopiesFile.find(".csv") != std::string::npos || this->physicalCopiesFile.find(".txt") != std::string::npos)
	{
		ifstream file(this->physicalCopiesFile);
		bool is_empty_file = (file.peek() == std::ifstream::traits_type::eof());
		file.close();
		ofstream output_file(this->physicalCopiesFile, ios::app);
		if (is_empty_file)
			output_file << copy_evidence;
		else
			output_file << endl << copy_evidence;
		output_file.close();
	}
	else
	{
		this->save_physical_copies_to_html();
	}
}

int Service::find_evidence_index_in_physical_copies_by_id(const std::string& id) const
{
	/*
	Find an evidence in the list of physical copies
	parameter: id - the id of the evidence
	return:
		-1 if evidence if not found
		its index in the list otherwise
	*/
	auto iterator = std::find_if(this->physicalCopies.begin(), this->physicalCopies.end(), [id](const Evidence evidence) {return evidence.get_id() == id; });
	if (iterator == this->physicalCopies.end())
		return -1;
	else
		return std::distance(this->physicalCopies.begin(), iterator); }

const std::vector<Evidence>& Service::get_physical_copies() const
{
	return this->physicalCopies;
}

int Service::get_number_of_physical_copies() const
{
	return this->physicalCopies.size();
}

void Service::filter_evidences_by_measurement_and_quantity(vector<Evidence>& filtered_list, const std::string& measurement, const double quantity) const
{
	/*
	Filter evidences by measurement and quantity
	parameter: filtered_list - the list used to return the filtered evidences
			   measurement - the exact measurement
			   quantity - the minimum quantity
	If measurement is empty or the quntity is -1 filter evidences only by the other condition
	*/
	vector<Evidence> evidences = this->get_evidences();
	if (measurement != "" && quantity != -1)
	{
		copy_if(evidences.begin(), evidences.end(), back_inserter(filtered_list), [measurement, quantity](const Evidence evidence)->bool { return evidence.get_measurement() == measurement && evidence.get_quantity() >= quantity; });
	}
	else if (measurement == "")
	{
		copy_if(evidences.begin(), evidences.end(), back_inserter(filtered_list), [measurement, quantity](const Evidence evidence)->bool { return evidence.get_quantity() >= quantity; });
	}
	else
	{
		copy_if(evidences.begin(), evidences.end(), back_inserter(filtered_list), [measurement, quantity](const Evidence evidence)->bool { return evidence.get_measurement() == measurement; });
	}
}

void Service::set_repository_file(const std::string& file)
{
	/*
	Set the file name for the text repository
	parameter: file - the name of the file
	Set the file name, if the repository of the service is a text repository
	Throw an exception if the repository of teh service is not a text one
	*/
	try
	{
		TextFileRepository& text_repository = dynamic_cast<TextFileRepository&>(this->repository);
		text_repository.set_file_name(file);
	}
	catch (bad_cast)
	{
		throw ServiceException("Wrong repository type!\n");
	}
}

void Service::set_physical_copies_file(const std::string& file)
{
	this->physicalCopiesFile = file;
}

