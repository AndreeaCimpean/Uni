#include "Lab11.h"

Lab11::Lab11(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
