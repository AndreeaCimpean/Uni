#pragma once
#include "TextFileRepository.h"

class CSVRepository : public TextFileRepository
{
};
