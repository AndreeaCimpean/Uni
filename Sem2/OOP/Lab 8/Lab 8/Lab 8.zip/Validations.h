#pragma once
#include <string>

void check_measurement(const std::string& measurement);
void check_image_clarity_level(const std::string& imageClarityLevel);
void check_quantity(const std::string& quantity);