#include "domain.h"
#include <string.h>

Profile create_profile(int profileIdNumber, char placeOfBirth[], char psychologicalProfile[], int yearsOfRecordedService)
{
	Profile newProfile;
	strcpy(newProfile.placeOfBirth, placeOfBirth);
	strcpy(newProfile.psychologicalProfile, psychologicalProfile);
	newProfile.profileIdNumber = profileIdNumber;
	newProfile.yearsOfRecordedService = yearsOfRecordedService;
	return newProfile;
}

int get_profile_id_number(Profile profile)
{
	return profile.profileIdNumber;
}

int get_years_of_recorded_service(Profile profile)
{
	return profile.yearsOfRecordedService;
}

char* get_place_of_birth(Profile profile)
{
	return profile.placeOfBirth;
}

char* get_pshycological_profile(Profile profile)
{
	return profile.psychologicalProfile;
}
