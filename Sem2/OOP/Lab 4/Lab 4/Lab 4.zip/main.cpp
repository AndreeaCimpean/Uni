#include <crtdbg.h>
#include "Repository.h"
#include "Service.h"
#include "UI.h"
#include "Repository.h"

using namespace std;

int main()
{
	Repository repository{};
	Service service{ repository };
	UI ui{ service };
	ui.run();
	_CrtDumpMemoryLeaks();
	return 0;
}